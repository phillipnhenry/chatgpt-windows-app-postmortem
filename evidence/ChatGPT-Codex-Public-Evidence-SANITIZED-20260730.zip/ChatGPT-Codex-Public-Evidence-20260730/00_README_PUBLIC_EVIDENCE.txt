CHATGPT / CODEX WINDOWS APP — PUBLIC EVIDENCE PACKAGE

This package is intended for attachment to a public issue in:
https://github.com/openai/codex/issues

Privacy review:
- Windows username replaced with <USER>.
- Local project names and project paths redacted.
- Local installation, workspace, and thread identifiers redacted.
- Raw global application state was intentionally excluded.
- Broad filesystem inventories were intentionally excluded.
- The screenshots expose only the Microsoft Store package name/version and
  the Windows error dialog.

FILES

01_Crash_Dialog_After_Winget_Reinstall.png
  Failure after forced uninstall/reinstall using the Microsoft Store product ID.

02_Crash_Dialog_After_Direct_Microsoft_Store_Reinstall.png
  Same failure after reinstalling directly through the Microsoft Store UI.

03_Cleanup_Long_Path_and_Directory_Errors_SANITIZED.txt
  Cleanup failures involving deeply nested application/browser data.

04_Sandbox_Default_Profile_Access_Denied_Condensed_SANITIZED.txt
  Condensed evidence of the runtime repeatedly resolving C:\Users\Default.

05_Sandbox_Default_Profile_Access_Denied_Line_Results_SANITIZED.txt
  Line-oriented evidence of repeated Default-profile access failures.

06_Runtime_Sequence_Store_Build_26.721.11231.0_SANITIZED.txt
  Runtime sequence tied to Store package build 26.721.11231.0.

07_Recovery_Backup_Counts_and_Robocopy_SANITIZED.txt
  Recovery scale and backup verification with personal paths redacted.

SHA256SUMS.txt
  Integrity hashes for all files in this package.

Full unredacted logs should not be posted publicly. They can be supplied
privately to an OpenAI or Microsoft engineer when a secure upload channel is
provided.
